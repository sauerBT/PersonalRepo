# -*- coding: utf-8 -*-
"""
Created on Thurday Sep 9 2021
@author: Brian Sauerborn
"""

import numpy as np
import matplotlib.pyplot as plt
from CSTR_Models import *
from NumericalMethods import *
import pandas as pd

def cstrRT(yinit, yin, M_cv, dMdt, q1, m_in, Ncstr):
    if yin.shape[0] > 1: # check for updating concentration input over time.  If not, y_in will automatically be broadcast
            tn = len(yin)
            assert len(m_in) == tn
    assert yin.shape[1] > 0, 'Input concentration must have AT LEAST 1 stream'
    x_streams = len(yin[0])

    xplot = np.empty((0))
    yplot = np.empty((0))
    #plt.plot(x_streams*[0], yinit.transpose(1,0)[0,::], 'go') # initialize plot
    plt.plot(0, yinit.transpose(1,0)[0,1], 'go') # initialize plot
    plt.xlabel("time")
    plt.ylabel("concentration(x)")
    plt.pause(0.005)
    for t in tqdm(range(tn)):
        # Solve ODE
        [x_n,y_rk4_n] = rk4_2d(cstrN, x0 = 0, y0 = yinit, xn = 1, n=10, args=(yin[t,::], M_cv, dMdt, q1, m_in[t], x_streams, Ncstr))
        assert y_rk4_n.shape[2] == x_streams, 'number of solution streams does not match the number of input streams'
        if (t == 0): # base case
            xplot = np.append(xplot, t)
            yplot = y_rk4_n[9,::,::]
            yinit = yplot
            #plt.plot(x_streams*[t+1], yplot[::, (Ncstr - 1)], 'm.', markersize = 1)
            plt.plot([t+1], yplot[1, (Ncstr - 1)], 'm.', markersize = 1)
            plt.pause(0.00001)
            
        else:
            xplot = np.append(xplot, t)
            yplot = np.dstack([yplot, y_rk4_n[9,::,::]])
            yinit = yplot[::,::,t]
            #plt.plot(x_streams*[t+1], yplot[::, (Ncstr - 1), t], 'm.', markersize = 1)
            plt.plot([t+1], yplot[1, (Ncstr - 1), t], 'm.', markersize = 1)
            plt.pause(0.00001)
    yplot = yplot.transpose(2, 0, 1) # transpose y output to to following dimensions: yn[iteration #][component #][CSTR #]
    return yplot

def readRTDExp(file):
    my_export = pd.read_csv(file, index_col = 0, header = 0, skiprows = 0) #before index_col = 0 but excluded first column
    df = my_export.set_index('Date')
    df = df.loc[:, ~df.columns.str.contains('^Unnamed')]
    return [df]

# Import and format RTD data
file = 'C:\\Users\\brian\\iCloudDrive\\GIT\\BrianPersonalCodingRepo\\006_RTDModels\\PythonRealTimeNCSTR\\IMA_RTD_Data-v1.csv'
[df] = readRTDExp(file)
F1_Flow = np.array(df['F1_CURR_FLW/PV.CV'])/3.6
API_Flow = np.array(df['F2_CURR_FLW/PV.CV'])/3.6
F3_Flow = np.array(df['F3_CURR_FLW/PV.CV'])/3.6
Ftot_Flow = (F1_Flow) + (API_Flow) + (F3_Flow)
x1_in = F1_Flow/Ftot_Flow
x2_in = API_Flow/Ftot_Flow
x3_in = F3_Flow/Ftot_Flow
Blend_Wt = np.array(df['BL_CURR_WGT/PV.CV'])*1000
API_x2 = (np.array(df['API_CONCEN1/PV.CV']) - .04)/100
RTD_X1 = np.array(df['RTD-4/XO_L1.CV'])
RTD_X2 = np.array(df['RTD-4/XO_L2.CV'])
RTD_X3 = np.array(df['RTD-4/XO_L3.CV'])
'''
present concentration inputs as mass % in a matrix of the following dimensions: 
X_in[concentration @ time tn, interval = 1 sec][concentration at steam x, stream increases (i.e. stream 1 is @ column 0)]
'''

X_in = np.array([x1_in, x2_in, x3_in]).T 

"""Get number of streams"""
x_streams = len(X_in[0])
#x = int(input("Enter number of streams: "))
Ncstr = int(input("Enter number of CSTRs (must be a whole number): "))
initTime = int(input("Enter initial sample time to use (must be a whole number): "))
sampleSize = int(input("Enter number of samples to use (must be a whole number): "))

yin = X_in[initTime:(sampleSize + initTime)][::]
m_in = list(Ftot_Flow[initTime:(initTime + sampleSize)][::])
API_Conc = API_x2[initTime:(sampleSize + initTime)]
x3 = np.linspace(0, sampleSize, sampleSize)

M = 2000 # total mass
Mss = 2000 # mass at steady state
dMdt = 0
q1 = 0 # % backmix

yinit = X_in[0,::]

yinit = np.tile(yinit, reps=(Ncstr,1)).T

print(f'API concentration array size: {np.shape(API_Conc)}')
print(f'API concentration time array size: {np.shape(x3)}')
print("yinit shape is: ", np.shape(yinit))
assert list(np.shape(yinit)) == [Ncstr,x_streams], "Initial condition shape wrong"

#initialize plot
#plt.plot(x_streams*[0], yinit.transpose(1,0)[0,::], 'go', x_streams*[(sampleSize - 1)], yin[(sampleSize - 1),::], 'ro', x3, API_Conc, 'b-') # initialize plot
plt.plot(0, yinit.transpose(1,0)[0,1], 'go', sampleSize - 1, yin[(sampleSize - 1),1], 'ro', x3, API_Conc, 'b-') # initialize plot
cstrRT(yinit, yin, M, dMdt, q1, m_in, Ncstr)
plt.show()


"""
[x_old,y_rk4_old] = rk4_2d(cstrN, x0 = 0, y0 = yinit, xn = len(yin), n=(len(yin)*10), args=(yin, M, dMdt, q2, m11, x_streams, Ncstr))
#plot prep
x1 = x_streams*[0] # initial time conditions
y1 = yinit[0,::].T # initial concentration conditions
x2 = x_streams*[len(yin)] # End time
y2 = yin[len(yin) - 1][::] #projected end condition
x3 = x_old
y3 = y_rk4_old[::, ::,  Ncstr - 1]

assert len(x1) == len(y1), "Incorrect initial conditions dimensions"
assert len(x2) == len(y2), "Incorrect end conditions dimensions"
assert len(x3) == len(y3), "Incorrect RK4 output dimensions"

plt.plot(x1, y1, 'go', x2, y2, 'ro', x3, y3,'k-')
plt.show()
"""