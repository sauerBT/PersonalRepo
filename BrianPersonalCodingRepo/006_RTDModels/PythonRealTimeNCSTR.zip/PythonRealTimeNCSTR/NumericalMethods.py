# -*- coding: utf-8 -*-
"""
Created on Thurday Sep 9 2021


@author: Brian Sauerborn
"""
import numpy as np
from tqdm import tqdm

def rk4_1d(func,x0,y0,xn,n,args):
    from tqdm import tqdm

    # Calculating step size
    h = (xn-x0)/n
    xout = np.linspace(x0,xn,n)
    yn = np.empty((0))
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("Solving Differential...")
    print("------------------------------------------------------------------------------------------------------------------------------")
    for i in tqdm(range(n)):

        k1 = h * (func(y0, x0,*args))
        k2 = h * (func((y0+k1/2), (x0+h/2), *args))
        k3 = h * (func((y0+k2/2), (x0+h/2), *args))
        k4 = h * (func((y0+k3), (x0+h), *args))
        k = (k1+2*k2+2*k3+k4)/6
        if (i==0): # base case
            y0 = y0 + k
            yn = y0
        else:
            y0 = y0 + k
            yn = np.vstack([yn, y0])
        x0 = x0+h
    return [xout,yn]

def rk4_2d(func,x0,y0,xn,n,args):
    # Function outputs include:
    # 1) a vector containing the iterated time values
    # 2) dydt[component number i][CSTR number n]
    
    # Calculating step size
    h = (xn-x0)/n
    assert h>0, "Step size less than zero"
    xout = np.linspace(x0,xn,n)
    yn = np.empty((0)) # initialize output array
    for i in (range(n)):
        k1 = h * (func(y0, x0,*args))
        k2 = h * (func((y0+k1/2), (x0+h/2), *args))
        k3 = h * (func((y0+k2/2), (x0+h/2), *args))
        k4 = h * (func((y0+k3), (x0+h), *args))
        k = (k1+2*k2+2*k3+k4)/6
        if (i==0): # base case
            y0 = y0 + k
            yn = y0
        else:
            y0 = y0 + k
            yn = np.dstack([yn, y0])
        x0 = x0+h
    yn = yn.transpose(2, 0, 1) # transpose y output to to following dimensions: yn[iteration #][component #][CSTR #]
    return [xout,yn]